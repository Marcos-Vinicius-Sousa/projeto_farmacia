package com.projeto_p2.farmacia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmaciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
